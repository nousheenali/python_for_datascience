
def count_characters(text):
    return len(text)

def capitalize(text):
    return text.upper()

def to_lowercase(text):
    return text.lower()

def reverse(text):
    return text[::-1]

def camel_case(text):
    return text.title()

def palindrome(text):
    return text == text[::-1]



