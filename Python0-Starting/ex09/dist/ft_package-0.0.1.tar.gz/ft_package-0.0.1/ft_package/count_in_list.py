
def count_in_list(list, value):
    return list.count(value)